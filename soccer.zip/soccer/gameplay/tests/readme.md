
# RoboCup Python tests

This folder contains all of our tests for our python code.

See `../run_tests.sh` for more info
