import composite_behavior
import behavior
import skills.pivot_kick
import skills.pass_receive
import skills.line_kick_receive
import constants
import robocup
import time
import main
import enum
import logging


# This handles passing from one bot to another
# Simply run it and set it's receive point, the rest is handled for you
# It starts out by assigning a kicker and a receiver and instructing them to lineup for the pass
# Once they're aligned, the kicker kicks and the receiver adjusts itself based on the ball's movement
# Note: due to mechanical limitations, a kicker often gets stuck trying to adjust its angle while it's just outside of it's
#       aim error threshold.  If this happens, the ForwardPass will adjust the receive point slightly
#       because it's easier to move the receiver over a bit than have the kicker adjust its angle.  This solves
#       the problem of having a pass get stuck indefinitely while the kicker sits there not moving.
# TODO: # If an opponent blocks the pass channel, it will wait until it moves - you can cancel it at this point if you wish
# As soon as the kicker kicks, it is no longer and is released by this behavior so other behaviors can be assigned to it
# If the receiver gets the ball, ForwardPass transitions to the completed state, otherwise it goes to the failed state
class ForwardPass(composite_behavior.CompositeBehavior):

    KickPower = 0.4

    class State(enum.Enum):
        preparing = 1  # the kicker is aiming and the receiver is getting ready
        kicking = 2  # waiting for the kicker to kick
        receiving = 3  # the kicker has kicked and the receiver is trying to get the ball

    ## Skillreceiver is a class that will handle the receiving robot. See pass_receive and angle_receive.
    # Using this, you can change what the receiving robot does (rather than just receiving the ball, it can pass or shoot it).
    def __init__(self, receive_point=None, skillreceiver=None):
        super().__init__(continuous=False)

        # This creates a new instance of skillreceiver every time the constructor is
        # called (instead of pulling from a single static instance).
        if skillreceiver == None:
            skillreceiver = skills.line_kick_receive.LineKickReceive()

        self.receive_point = receive_point
        self.skillreceiver = skillreceiver

        for state in ForwardPass.State:
            self.add_state(state, behavior.Behavior.State.running)

        self.add_transition(behavior.Behavior.State.start,
                            ForwardPass.State.preparing, lambda: True,
                            'immediately')

        self.add_transition(
            ForwardPass.State.preparing, ForwardPass.State.kicking,
            lambda: (self.subbehavior_with_name('kicker').state == skills.pivot_kick.PivotKick.State.aimed and self.subbehavior_with_name('receiver').state == self.skillreceiver.State.aligned),
            'kicker and receiver ready')

        self.add_transition(
            ForwardPass.State.kicking, ForwardPass.State.receiving,
            lambda: self.subbehavior_with_name('kicker').state == behavior.Behavior.State.completed,
            'kicker kicked')

        self.add_transition(
            ForwardPass.State.receiving, behavior.Behavior.State.completed,
            lambda: self.subbehavior_with_name('receiver').state == behavior.Behavior.State.completed,
            'pass received!')

        self.add_transition(
            ForwardPass.State.receiving, behavior.Behavior.State.failed,
            lambda: self.subbehavior_with_name('receiver').state == behavior.Behavior.State.failed,
            'pass failed :(')

    # set the location where the receiving bot should camp out and wait for the ball
    # Default: None
    @property
    def receive_point(self):
        return self._receive_point

    @receive_point.setter
    def receive_point(self, value):
        self._receive_point = value

        # set receive_point for kicker and receiver (if present)
        if self.has_subbehavior_with_name('kicker'):
            self.subbehavior_with_name('kicker').target = self.receive_point
        if self.has_subbehavior_with_name('receiver'):
            self.subbehavior_with_name(
                'receiver').receive_point = self.receive_point

    def on_enter_running(self):
        receiver = self.skillreceiver
        receiver.restart()
        receiver.receive_point = self.receive_point + robocup.Point(-1.0, -3.0)
        self.add_subbehavior(receiver, 'receiver', required=True)

    def on_exit_running(self):
        self.remove_subbehavior('receiver')

    def on_enter_kicking(self):
        self.subbehavior_with_name('kicker').enable_kick = True

    def on_enter_preparing(self):
        kicker = skills.pivot_kick.PivotKick()
        kicker.target = self.receive_point
        kickpower = ForwardPass.KickPower
        kicker.kick_power = kickpower
        kicker.enable_kick = False  # we'll re-enable kick once both bots are ready

        # we use tighter error thresholds because passing is hard
        kicker.aim_params['error_threshold'] = 0.2
        kicker.aim_params['max_steady_ang_vel'] = 3.0
        kicker.aim_params['min_steady_duration'] = 0.15
        kicker.aim_params['desperate_timeout'] = 3.0
        self.add_subbehavior(kicker, 'kicker', required=True)

        # receive point renegotiation
        self._last_unsteady_time = None
        self._has_renegotiated_receive_point = False

    def execute_running(self):
        # The shot obstacle doesn't apply to the receiver
        if self.has_subbehavior_with_name('kicker'):
            kicker = self.subbehavior_with_name('kicker')
            receiver = self.subbehavior_with_name('receiver')
            kicker.shot_obstacle_ignoring_robots = [receiver.robot]

    # gets robots involved with the pass
    def get_robots(self):
        kicker = None
        receiver = None
        if self.has_subbehavior_with_name('kicker'):
            kicker = self.subbehavior_with_name('kicker')
        if self.has_subbehavior_with_name('receiver'):
            receiver = self.subbehavior_with_name('receiver')
        toReturn = []
        if receiver != None and receiver.robot != None:
            toReturn.extend([receiver.robot])
        if kicker != None and kicker.robot != None:
            toReturn.extend([kicker.robot])
        return toReturn

    def on_enter_receiving(self):
        # once the ball's been kicked, the kicker can go relax or do another job
        self.subbehavior_with_name('receiver').ball_kicked = True
        self.remove_subbehavior('kicker')

    def __str__(self):
        desc = super().__str__()
        desc += "\n    rcv_pt=" + str(self.receive_point)
        return desc
