
# Evaluation

This folder contains code for game analysis/evaluation.  The code here should answer questions such as:

* Is the ball in our/their goal zone?
* Is the ball moving towards our/their goal?
* Is a shot open from pt1 to pt2?
* Who has the ball?
