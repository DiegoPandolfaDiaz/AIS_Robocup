#include <boost/python.hpp>

extern "C" {
PyObject* PyInit_robocup();
}
